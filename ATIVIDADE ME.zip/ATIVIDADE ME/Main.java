public class Main {
    public static void main(String[] args) {
        ConjuntoEspalhamento conjunto = new ConjuntoEspalhamento();

        conjunto.adiciona("João");
        conjunto.adiciona("Pedro");
        conjunto.adiciona("Maria");
        conjunto.adiciona("Enzo");

        System.out.println("Contém João? " + conjunto.contem("João"));
        System.out.println("Contém Pedro? " + conjunto.contem("Pedro"));
        System.out.println("Contém Maria? " + conjunto.contem("Maria"));
        System.out.println("Contém Enzo? " + conjunto.contem("Enzo"));
        System.out.println("Contém Arthur? " + conjunto.contem("arthur"));
        System.out.println("Contém Flávia? " + conjunto.contem("Flávia"));

    }
}
