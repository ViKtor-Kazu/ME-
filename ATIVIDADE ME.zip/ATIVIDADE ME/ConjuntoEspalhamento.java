
import java.util.LinkedList;
import java.util.List;

public class ConjuntoEspalhamento {

    private List<String>[] tabela;
    private int tamanho;

    public ConjuntoEspalhamento() {
        this.tabela = new LinkedList[52]; // Aumentando o tamanho da tabela
        for (int i = 0; i < tabela.length; i++) {
            tabela[i] = new LinkedList<>();
        }
        this.tamanho = 0;
    }

    private int calculaIndice(String palavra) {
        int soma = 0;
        for (int i = 0; i < palavra.length(); i++) {
            soma += palavra.charAt(i);
        }
        return soma % tabela.length; // Utilizando o resto da divisão para calcular o índice
    }

    public void adiciona(String palavra) {
        if (!contem(palavra)) {
            int indice = calculaIndice(palavra);
            tabela[indice].add(palavra);
            tamanho++;
        }
    }

    public List<String> todasPalavras() {
        List<String> palavras = new LinkedList<>();
        for (List<String> lista : tabela) {
            palavras.addAll(lista);
        }
        return palavras;
    }

    public void remove(String palavra) {
        int indice = calculaIndice(palavra);
        tabela[indice].remove(palavra);
        tamanho--;
    }

    public boolean contem(String palavra) {
        int indice = calculaIndice(palavra);
        return tabela[indice].contains(palavra);
    }

    public int tamanho() {
        return tamanho;
    }

    public void imprimeTabela() {
        for (int i = 0; i < tabela.length; i++) {
            System.out.print("[" + i + "]: ");
            for (String palavra : tabela[i]) {
                System.out.print(palavra + " ");
            }
            System.out.println();
        }
    }
}
